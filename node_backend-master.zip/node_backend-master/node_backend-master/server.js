const express = require('express');
const bodyParser=require('body-parser');
const mongoose = require('mongoose');

// setting up express
const app = express();
const uri = "mongodb+srv://zilin_wang:200041238@cluster0-zcgfy.gcp.mongodb.net/test?retryWrites=true&w=majority"

mongoose.connect(uri,{useNewUrlParser: true, useUnifiedTopology: true });

app.use(express.static('public')); // serve simple html
app.use(bodyParser.json()); //middleware
app.use('/api', require('./routes/api')); // route setup
app.use(function(err,req,res,next){ //error handling
    console.log(err.message);
    res.status(422).send({error: err.message})
});

// api
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Listening on port ${PORT}...`);
});

/*-----------------------Rainbow API SDK*/
// Load the SDK
let RainbowSDK = require("rainbow-node-sdk");

// Define your configuration
let options = {
    "rainbow": {
        "host": "sandbox",
    },
    "credentials": {
        "login": "aaronkhoo@live.com",
        "password": "6]<epFf$Er'0"
    },
    "application": {
        "appID": "a58cfac05b0711eabf7e77d14e87b936",
        "appSecret": "JnjQaOpCW9Pc3u2IUQAvyjyiAEINpBo47Vb5S3jSUxHdgQkc3pqFFXGHJPojXbGu",
    },
    // Logs options
    "logs": {
        "enableConsoleLogs": true,            // Default: true
        "enableFileLogs": false,              // Default: false
        "file": {
            "path": '/var/tmp/rainbowsdk/',   // Default path used
            "level": 'debug'                  // Default log level used
        }
    },
    /*//ProxyImpl
    "proxy": {
        "host": '192.168.0.254',
        "port": 8081,
        "protocol": 'http',
        "user": "",
        "password": ""
    },*/
    // IM options
    "im": {
        "sendReadReceipt": true   // True to send the the 'read' receipt automatically
    }
};

// Instantiate the SDK
let rainbowSDK = new RainbowSDK(options);
rainbowSDK.start();
